package com.hms.dao;

public class QueryMapper 
{
	public static final String SELECT_QUERY = "select hotel_Id,hotel_Name,hotel_Location,hotel_Email,hotel_Mobile,hotel_Status from Hotel_tbl";
}
