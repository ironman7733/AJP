package com.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.hms.bean.HotelBean;
import com.hms.exception.HotelException;
import com.hms.util.DbConnection;



public class HotelDaoImpl implements IHotelDao
{

	@Override
	public List<HotelBean> viewAllHotels() throws HotelException 
	{
		List<HotelBean> list = new ArrayList<HotelBean>();
		Connection con = DbConnection.getConnection(); 
		
		try {
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.SELECT_QUERY);
			
			ResultSet rst = pstmt.executeQuery();
			
			while(rst.next())
			{
				HotelBean bean = new HotelBean();
				bean.setHotelId(rst.getInt("hotel_Id"));
				bean.setHotelName(rst.getString("hotel_Name"));
				bean.setHotelLocation(rst.getString("hotel_Location"));
				bean.setHotelEmail(rst.getString("hotel_Email"));
				bean.setHotelMobile(rst.getLong("hotel_Mobile"));
				bean.setHotelStatus(rst.getString("hotel_Status"));
				list.add(bean);
			}
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		return (list);
	}
	
}
