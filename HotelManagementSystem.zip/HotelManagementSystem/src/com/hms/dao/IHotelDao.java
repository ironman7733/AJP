package com.hms.dao;

import java.util.List;
import com.hms.bean.HotelBean;
import com.hms.exception.HotelException;
public interface IHotelDao 
{
	public List<HotelBean> viewAllHotels() throws HotelException;
}
