package com.ems.bean;

import java.time.LocalDate;


public class TrainBean 
{
	private String trainId;
	private String trainName;
	private String trainDest;
	private LocalDate trainDept;
	private int trainSeats;
	private double trainFare;
	public String getTrainId() {
		return trainId;
	}
	public void setTrainId(String trainId) {
		this.trainId = trainId;
	}
	public String getTrainName() {
		return trainName;
	}
	public void setTrainName(String trainName) {
		this.trainName = trainName;
	}
	public String getTrainDest() {
		return trainDest;
	}
	public void setTrainDest(String trainDest) {
		this.trainDest = trainDest;
	}
	public LocalDate getTrainDept() {
		return trainDept;
	}
	public void setTrainDept(LocalDate trainDept) {
		this.trainDept = trainDept;
	}
	public int getTrainSeats() {
		return trainSeats;
	}
	public void setTrainSeats(int trainSeats) {
		this.trainSeats = trainSeats;
	}
	public double getTrainFare() {
		return trainFare;
	}
	public void setTrainFare(double trainFare) {
		this.trainFare = trainFare;
	}
	
	
	
	

}
