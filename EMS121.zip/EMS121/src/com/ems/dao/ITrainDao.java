package com.ems.dao;

import java.util.List;

import com.ems.bean.TrainBean;
import com.ems.exception.TrainException;

public interface ITrainDao {

	public List<TrainBean> viewAllTrains() throws TrainException;
	public TrainBean getTrainDetails(String id) throws TrainException;
	public boolean bookTrain (String id,int seats) throws TrainException;
	
}
