package com.registration.util;


import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;



import com.registration.exception.RegistrationException;

public class DbConnection {
	public static Connection getConnection() throws RegistrationException{
		
		Connection con = null;
		try {
			InitialContext ic = new InitialContext();
			DataSource ds = (DataSource) ic.lookup("java:/OracleDS");
			con = ds.getConnection();
		} catch (NamingException e) {

		    System.out.println(e.getMessage());
		} catch (SQLException e) {

		   System.out.println(e.getMessage());
		}
       return con;
	}

}
