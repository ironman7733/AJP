package com.registration.controller;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.registration.dto.RegistrationDto;

/**
 * Servlet implementation class PrintServlet
 */
@WebServlet("/PrintServlet")
public class PrintServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PrintServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		List<RegistrationDto> list = (List<RegistrationDto>)request.getAttribute("list");
		
		for(RegistrationDto User : list)
		{

			out.println("<h1>Print Servlet");
			out.println("<table border=\"1\"><tr><td>"+User.getFirstname()+"</td>");
			out.println("<td>"+User.getLastname()+"</td>");
			out.println("<td>"+User.getPassword()+"</td>");
			out.println("<td>"+User.getGender()+"</td>");
			out.println("<td>"+User.getSkillset()+"</td>");
			out.println("<td>"+User.getCity()+"</td>");
			out.println("</tr></table>");
			
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
