package com.ewp.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ewp.bean.EmployeeBean;
import com.ewp.exception.EmployeeException;
import com.ewp.service.EmployeeServiceImpl;
import com.ewp.service.IEmployeeService;

/**
 * Servlet implementation class EmployeeController
 */
@WebServlet("/EmployeeController")
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	
	
    public EmployeeController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
			response.setContentType("text/html");
			PrintWriter out=response.getWriter();
			String empName=request.getParameter("empname");
			String salary=request.getParameter("empsalary");
			double empSalary=Double.parseDouble(salary);
			EmployeeBean bean=new EmployeeBean();
			bean.setEmployeeName(empName);
			bean.setEmployeeSalary(empSalary);
			//out.println(bean.getEmployeeSalary()+bean.getEmployeeName());
			IEmployeeService service=new EmployeeServiceImpl();
			
			int empid=0;
			try {
				empid=service.addEmployee(bean);
			} catch (EmployeeException e) {
				out.println(e.getMessage());
			}
			//empid = bean.getEmployeeId();
			/*out.println("Showing Emp Id Here");
			out.println("ID: "+empid);
			*/
			out.println("<h1>Employee Added Successfully</h1>");
			out.println("<h2>Employee ID = "+empid+"</h2>");
			
			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
