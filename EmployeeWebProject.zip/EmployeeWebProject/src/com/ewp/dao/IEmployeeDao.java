package com.ewp.dao;

import com.ewp.bean.EmployeeBean;
import com.ewp.exception.EmployeeException;

public interface IEmployeeDao {

	public int addEmployee(EmployeeBean bean) throws EmployeeException;
}
