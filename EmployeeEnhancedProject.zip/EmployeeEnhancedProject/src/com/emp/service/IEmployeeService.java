package com.emp.service;

import java.util.List;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;

public interface IEmployeeService {
	
	public int addEmployee(EmployeeBean employee) throws EmployeeException;	
	public EmployeeBean findEmployeeById(int id) throws EmployeeException;
	public EmployeeBean deleteEmployeeById(int id) throws EmployeeException;
	public List<EmployeeBean> showAllEmployee() throws EmployeeException;

}
