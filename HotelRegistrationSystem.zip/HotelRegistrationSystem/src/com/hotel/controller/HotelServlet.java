package com.hotel.controller;



import java.io.IOException;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hotel.bean.HotelBean;
import com.hotel.exception.HotelException;
import com.hotel.service.HotelServiceImpl;
import com.hotel.service.IHotelService;

/**
 * Servlet implementation class HotelServlet
 */
@WebServlet("*.obj")
public class HotelServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HotelServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doPost(request, response);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        
        
        HotelBean hotel = new HotelBean();
        IHotelService service = new HotelServiceImpl();
        String target = "";
        String targetHome = "home.jsp";
        String targetAdd = "addhotel.jsp";
        String targetSuccess = "addsuccess.jsp";
        String targetError = "error.jsp";
        String targetException = "errorexception.jsp";
        String targetActivation = "activationsuccess.jsp";
        String targetVerify = "verifyotp.jsp";
        String path = request.getServletPath().trim();
        HttpSession session = request.getSession(true);
        switch (path) 
        {
        
        
        	case "/home.obj":
        		target = targetHome;
        		break;
            
            case "/addhotel.obj":
                target = targetAdd;
                break;
            
            
            case "/register.obj":
                String hotelname = request.getParameter("hotelname").trim();
                System.out.println("IN HOTELSERVLET:"+hotelname);
                
                String hotellocation = request.getParameter("hotellocation").trim();
                System.out.println("IN HOTELSERVLET:"+hotellocation);
                
                String hotelemail = request.getParameter("hotelemail").trim();
                System.out.println("IN HOTELSERVLET:"+hotelemail);
                
                long hotelmobile = Long.parseLong(request.getParameter("hotelmobile").trim());
                System.out.println("IN HOTELSERVLET:"+hotelmobile);
                hotel.setHotelName(hotelname);
                hotel.setHotelLocation(hotellocation);
                hotel.setHotelEmail(hotelemail);
                hotel.setHotelMobile(hotelmobile);
                
                System.out.println(hotel.getHotelLocation());
            try 
            {
                int hotelId = service.addHotel(hotel);
                if (hotelId != 0) 
                {
                    hotel.setHotelId(hotelId);
                    Random rd = new Random();
                    int num = rd.nextInt(2000);
                    session.setAttribute("otp", num);
                    session.setAttribute("email",hotel.getHotelEmail());
                    target = targetSuccess;
                }
                else
                {
                    target = targetError;
                }
            
            } 
            catch (HotelException e) 
            {

                System.out.println(e.getMessage());
                target = targetException;
            }
            break;
            
            case"/verifyotp.obj":
                target = targetVerify;
                break;
            
            
            case"/activatehotel.obj":
                String email = request.getParameter("hotelemail").trim();   
                int otp = Integer.parseInt(request.getParameter("otp").trim());
                String sessionemail = (String)session.getAttribute("email");
                Integer sessionotp = (Integer)session.getAttribute("otp");

                if(sessionotp == otp && sessionemail.equals(email))
                {
                    
                	//target = targetActivation;
                    try 
                    {
                        boolean flag = service.updateRegisterDetails(sessionemail);
                        System.out.println(flag);
                        if(flag)
                        {
                            target = targetActivation;
                        }
                    } 
                    catch (HotelException e) 
                    {

                        target=targetError;
                    }
                }
        }
        
        RequestDispatcher dispatcher = request.getRequestDispatcher(target);
        dispatcher.forward(request, response);
        
    }

}