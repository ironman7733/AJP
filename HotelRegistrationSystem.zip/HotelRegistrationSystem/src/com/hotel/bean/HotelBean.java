package com.hotel.bean;

public class HotelBean 
{

    private int hotelId;
    private String hotelName;
    private String hotelLocation;
    private String hotelEmail;
    private long hotelMobile;
    private String hotelStatus;
    public int getHotelId() {
        return hotelId;
    }
    public void setHotelId(int hotelId) {
        this.hotelId = hotelId;
    }
    public String getHotelName() {
        return hotelName;
    }
    public void setHotelName(String hotelName) {
        this.hotelName = hotelName;
    }
    public String getHotelLocation() {
        return hotelLocation;
    }
    public void setHotelLocation(String hotelLocation) {
        this.hotelLocation = hotelLocation;
    }
    public String getHotelEmail() {
        return hotelEmail;
    }
    public void setHotelEmail(String hotelEmail) {
        this.hotelEmail = hotelEmail;
    }
    public long getHotelMobile() {
        return hotelMobile;
    }
    public void setHotelMobile(long hotelMobile) {
        this.hotelMobile = hotelMobile;
    }
    public String getHotelStatus() {
        return hotelStatus;
    }
    public void setHotelStatus(String hotelStatus) {
        this.hotelStatus = hotelStatus;
    }
    public HotelBean(int hotelId, String hotelName, String hotelLocation,
            String hotelEmail, long hotelMobile, String hotelStatus) {
        super();
        this.hotelId = hotelId;
        this.hotelName = hotelName;
        this.hotelLocation = hotelLocation;
        this.hotelEmail = hotelEmail;
        this.hotelMobile = hotelMobile;
        this.hotelStatus = hotelStatus;
    }
    public HotelBean() {
        super();
        // TODO Auto-generated constructor stub
    }
    @Override
    public String toString() {
        return "HotelBean [hotelId=" + hotelId + ", hotelName=" + hotelName
                + ", hotelLocation=" + hotelLocation + ", hotelEmail="
                + hotelEmail + ", hotelMobile=" + hotelMobile
                + ", hotelStatus=" + hotelStatus + "]";
    }
    
}