package com.hotel.service;

import com.hotel.bean.HotelBean;
import com.hotel.exception.HotelException;



public interface IHotelService 
{
    public int addHotel(HotelBean hotel) throws HotelException; 
    public boolean updateRegisterDetails(String email) throws HotelException;
}