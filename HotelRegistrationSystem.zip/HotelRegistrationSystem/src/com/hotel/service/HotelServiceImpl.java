package com.hotel.service;

import com.hotel.bean.HotelBean;
import com.hotel.dao.HotelDaoImpl;
import com.hotel.dao.IHotelDao;
import com.hotel.exception.HotelException;

public class HotelServiceImpl implements IHotelService 
{
    private IHotelDao dao = new HotelDaoImpl(); 
    @Override
    public int addHotel(HotelBean hotel) throws HotelException 
    {
        
        return dao.addHotel(hotel);
    }
    @Override
    public boolean updateRegisterDetails(String email) throws HotelException {
        return dao.updateRegisterDetails(email);
    }

}