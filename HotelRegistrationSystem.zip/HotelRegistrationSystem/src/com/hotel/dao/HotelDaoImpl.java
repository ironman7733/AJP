package com.hotel.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.hotel.bean.HotelBean;
import com.hotel.exception.HotelException;
import com.hotel.util.DbConnection;

public class HotelDaoImpl implements IHotelDao
{
    
    private HotelBean bean = new HotelBean();

    @Override
    public int addHotel(HotelBean hotel) throws HotelException 
    {
        int id = 0;
        Connection conn = DbConnection.getConnection();
        String query=QueryMapper.INSERT_QUERY;
        try 
        {
            System.out.println(hotel.getHotelName());
            PreparedStatement pstmt=conn.prepareStatement(query);
            pstmt.setString(1, hotel.getHotelName());
            pstmt.setString(2, hotel.getHotelLocation());
            pstmt.setString(3, hotel.getHotelEmail());
            pstmt.setLong(4, hotel.getHotelMobile());
            int count=pstmt.executeUpdate();
            if(count<=0)
            {
                throw new HotelException("Insert failed. ");
            }
            query=QueryMapper.SELECT_ID_QUERY;
            pstmt=conn.prepareStatement(query);
            ResultSet res=pstmt.executeQuery();
            if(res.next())
            {
                id=res.getInt(1);
            }
            else
            {

                throw new HotelException("Unable to read from the sequence");
            }
            conn.close();
        } 
        catch (SQLException e) 
        {

            throw new HotelException(e.getMessage());
        }
        
        
        return id;
    }

    @Override
    public boolean updateRegisterDetails(String email) throws HotelException 
    {
        boolean flag=false;
        Connection con = DbConnection.getConnection();
        try 
        {
            PreparedStatement pstmt = con.prepareStatement(QueryMapper.UPDATE_QUERY);
            pstmt.setString(1,email);
            int count = pstmt.executeUpdate();
            if(count>0)
            {
                flag=true;
            }
        }
        catch (SQLException e) 
        {

             System.out.println(e.getMessage());
        }
        return flag;
    }

}