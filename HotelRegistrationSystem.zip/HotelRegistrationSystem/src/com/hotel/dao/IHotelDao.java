package com.hotel.dao;

import com.hotel.bean.HotelBean;
import com.hotel.exception.HotelException;
public interface IHotelDao 
{
    public int addHotel(HotelBean hotel) throws HotelException;
    public boolean updateRegisterDetails(String email) throws HotelException;
}