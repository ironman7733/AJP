package com.registration.controller;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import com.registration.dto.RegistrationDto;
import com.registration.exception.RegistrationException;
import com.registration.service.IRegistrationService;
import com.registration.service.RegistrationServiceImpl;

/**
 * Servlet implementation class RegistrationController
 */
@WebServlet("/RegistrationController")
public class RegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		IRegistrationService service = new RegistrationServiceImpl();

			response.setContentType("text/html");
			PrintWriter out=response.getWriter();
			String fname = request.getParameter("firstname");
			String lname = request.getParameter("lastname");
			String pass = request.getParameter("password");
			String gend = request.getParameter("r1");
			String [] sklset = request.getParameterValues("c1");
			String cty = request.getParameter("city");
			
			String skill="";
			/*for(String str : sklset)
			{
				skill = skill + str;
			}*/
			for(int i=0;i<sklset.length;i++){
				skill+=sklset[i];
			}
			RegistrationDto dto = new RegistrationDto();
		    dto.setFirstname(fname);
		    dto.setLastname(lname);
		    dto.setPassword(pass);
		    dto.setGender(gend);
		    dto.setSkillset(skill);
		    dto.setCity(cty);
		    
		    
		    int count = 0;  
		    try 
		    {
		    	//out.println(dto.toString());
				count = service.addUser(dto);
				//out.println("<h1>count = "+count);
				if(count>0)
				{
					   out.println("<h1>Registration done successfully");
				}
				else
				{
					 out.println("<h1>Registration Failed");
				}
			} 
		    catch (RegistrationException e) 
		    {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
