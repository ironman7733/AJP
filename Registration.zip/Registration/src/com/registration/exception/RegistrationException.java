package com.registration.exception;

public class RegistrationException extends Exception 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -2044508900151523430L;

	public RegistrationException(String message)
	{
		super(message);
	}

}
