package com.registration.service;

import com.registration.dao.IRegistrationDao;
import com.registration.dao.RegistrationDaoImpl;
import com.registration.dto.RegistrationDto;
import com.registration.exception.RegistrationException;

public class RegistrationServiceImpl implements IRegistrationService
{

	IRegistrationDao dao = new RegistrationDaoImpl();
	@Override
	public int addUser(RegistrationDto User) throws RegistrationException {
		
		int id = 0;
		id = dao.addUser(User);
		
		return id;
	}

}
