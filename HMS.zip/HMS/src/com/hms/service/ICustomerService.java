package com.hms.service;

import com.hms.bean.CustomerBean;
import com.hms.exception.CustomerException;



public interface ICustomerService 
{
	public int addCustomer(CustomerBean customer) throws CustomerException;	

}
