package com.hms.service;

import com.hms.bean.CustomerBean;
import com.hms.dao.CustomerDaoImpl;
import com.hms.dao.ICustomerDao;
import com.hms.exception.CustomerException;

public class CustomerServiceImpl implements ICustomerService
{
	
	private ICustomerDao customerDao=new CustomerDaoImpl();

	@Override
	public int addCustomer(CustomerBean bean) throws CustomerException 
	{
		
		int id = 0;
		id = customerDao.addCustomer(bean);
		
		//System.out.println("In Service:"+bean.toString());
		return id;
	}
}
	
	
	
		
	/*@Override
	public int addCustomer(CustomerBean bean) throws CustomerException 
	{
		int id=0;		
		if(validateFirstName(bean.getFirstName()))
		{
			id = customerDao.addCustomer(bean);
		}
		else
		{
			throw new CustomerException("CUSTOMER  NAME SHOULD HAVE A MINIMUM OF 4 CHARACTERS");
			
		}
		return id;
	}
		
	public boolean validateCustomerId(int id)
	{
		boolean flag=false;
		Pattern pattern=Pattern.compile("[0-9]{4}");
		Matcher matcher=pattern.matcher(String.valueOf(id));
		if(matcher.matches())
		{	
			flag=true;
		}
		else
		{
			flag=false;
		}
			return flag;
	}
	public boolean validateFirstName(String name)
	{
		boolean flag=false;
		Pattern pattern=Pattern.compile("[a-zA-Z/s]{4,}");
		Matcher matcher=pattern.matcher(name);
		if(matcher.matches())
		{	
			flag=true;
		}
		else
		{
			flag=false;
		}
			return flag;
	}*/

