package com.hms.dao;

public class QueryMapper 
{

	public static final String INSERT_QUERY="insert into hotel_customer(customerId,firstName,lastName,age,userName,password,mailId,mobileNo) values(cid_seq.nextval,?,?,?,?,?,?,?)";
	public static final String SELECT_ID_QUERY="select cid_seq.currval from dual";
	//public static final String SELECT_ALL_CUSTOMER_QUERY="select * from hotel_customer";
}
