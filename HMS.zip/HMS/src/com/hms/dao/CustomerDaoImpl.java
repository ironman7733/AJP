package com.hms.dao;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.hms.bean.CustomerBean;
import com.hms.exception.CustomerException;
import com.hms.util.DBConnection;



public class CustomerDaoImpl implements ICustomerDao
{
	
	//private CustomerBean bean = new CustomerBean();

	@Override
	public int addCustomer(CustomerBean bean) throws CustomerException 
	{
		int id=0;
		Connection con=DBConnection.getConnection();
		String query = QueryMapper.INSERT_QUERY;
		try 
		{
			PreparedStatement pstmt=con.prepareStatement(query);
			pstmt.setString(1, bean.getFirstName());
			pstmt.setString(2, bean.getLastName());
			pstmt.setInt(3, bean.getAge());
			pstmt.setString(4, bean.getUserName());
			pstmt.setString(5, bean.getPassword());
			pstmt.setString(6, bean.getMailId());
			pstmt.setLong(7, bean.getMobileNo());
			int count=pstmt.executeUpdate();
			if(count<=0)
			{
				
				throw new CustomerException("Insert failed... ");
			}
			query=QueryMapper.SELECT_ID_QUERY;
			pstmt=con.prepareStatement(query);
			ResultSet res=pstmt.executeQuery();
			if(res.next())
			{
				id=res.getInt(1);
			}
			else
			{
				
				throw new CustomerException("Unable to read from the sequence");
			}	
			con.close();
		}
		catch (SQLException e) 
		{
	
			throw new CustomerException(e.getMessage());
		}
		
		return (id);
	}
}

