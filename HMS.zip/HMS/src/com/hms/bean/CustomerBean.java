package com.hms.bean;

public class CustomerBean 
{

	private int customerId;
	private String firstName;
	private String lastName;
	private int age;
	private String userName;
	private String password;
	private String mailId;
	private long mobileNo;
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public CustomerBean(int customerId, String firstName, String lastName,
			int age, String userName, String password, String mailId,
			long mobileNo) {
		super();
		this.customerId = customerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.userName = userName;
		this.password = password;
		this.mailId = mailId;
		this.mobileNo = mobileNo;
	}
	public CustomerBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "CustomerBean [customerId=" + customerId + ", firstName="
				+ firstName + ", lastName=" + lastName + ", age=" + age
				+ ", userName=" + userName + ", password=" + password
				+ ", mailId=" + mailId + ", mobileNo=" + mobileNo + "]";
	}
	
	
}
