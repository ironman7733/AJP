package com.hms.pl;

import java.util.Scanner;

import com.hms.bean.CustomerBean;
import com.hms.exception.CustomerException;
import com.hms.service.CustomerServiceImpl;
import com.hms.service.ICustomerService;



public class CustomerMain 
{

	public static void main(String[] args)
	{
		//int cid;
		Scanner sc = new Scanner(System.in);
		ICustomerService customerService = new CustomerServiceImpl();
		System.out.println("Adding a Customer");
		
		System.out.println("Enter First Name:");
		String fname = sc.nextLine();
		System.out.println("Enter Last Name:");
		String lname = sc.nextLine();
		System.out.println("Enter Age:");
		int cage = sc.nextInt();
		sc.nextLine();
		System.out.println("Enter User Name:");
		String uname = sc.nextLine();
		System.out.println("Enter Password:");
		String pass = sc.nextLine();
		System.out.println("Enter Mail ID:");
		String mailid = sc.nextLine();
		System.out.println("Enter Mobile Number:");
		long mno = sc.nextLong();
		
		
		
		CustomerBean cust = new CustomerBean();
		cust.setFirstName(fname);
		cust.setLastName(lname);
		cust.setAge(cage);
		cust.setUserName(uname);
		cust.setPassword(pass);
		cust.setMailId(mailid);
		cust.setMobileNo(mno);
		System.out.println(cust.toString());
		

		try 
		{
			int id = customerService.addCustomer(cust);
			if (id > 0) 
			{
				System.out.println("Customer Added Successfully");
				System.out.println("Id: " + id);
			} 
			else
			{
				System.out.println("Customer Fail to Add");
			}
		} 
		catch (CustomerException e) 
		{
			System.out.println(e.getMessage());
		}

	}
}
