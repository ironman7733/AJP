package com.hms.exception;

public class CustomerException extends Exception
{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3488477576766738054L;

	public CustomerException(String message)
	{
		super(message);
	}
}
